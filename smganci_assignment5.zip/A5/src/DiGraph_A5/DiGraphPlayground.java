package DiGraph_A5;

public class DiGraphPlayground {

	public static void main(String[] args) {

		// thorough testing is your responsibility
		//
		// you may wish to create methods like
		// -- print
		// -- sort
		// -- random fill
		// -- etc.
		// in order to convince yourself your code is producing
		// the correct behavior
		// test1();
		topoTest();
	}

	public static void topoTest() {
		DiGraph d = new DiGraph();
		d.addNode(0, "a");
		d.addNode(1, "b");
		d.addEdge(0, "a", "b", 1, null);
		d.addNode(2, "c");
		d.addEdge(1, "b", "c", 1, null);
		d.addNode(3, "d");
		d.addEdge(2, "c", "d", 1, null);
		d.addNode(4, "e");
		d.addEdge(3, "b", "e", 1, null);
		d.addEdge(4, "e", "d", 1, null);
		String[] sort = new String[] { "a", "b", "c", "e", "d" };
		String[] sort2 = new String[] { "a", "b", "e", "c", "d" };
		String[] topo = d.topoSort();
		if (topo == null) {
			System.out.println("nullllll");
		}
	}

	public static void test1() {
		DiGraph d = new DiGraph();

		System.out.println(d.addNode(1, "test"));
		System.out.println(d.addNode(1, "cant have 2"));
		System.out.println(d.numNodes());
		d.addNode(2, "hello");

		System.out.println(d.numNodes());

		System.out.println("Add edge");
		System.out.println(d.addEdge(1, "hello", "test", 1, "edge"));
		System.out.println(d.numEdges());

		System.out.println("Add edge again");
		System.out.println(d.addEdge(1, "hello", "test", 1, "edge"));
		System.out.println(d.numEdges());

		System.out.println("delete edge");
		System.out.println(d.delEdge("hello", "test"));

		System.out.println("new edge size");
		System.out.println(d.numEdges());

	}

	public static void exTest() {
		DiGraph d = new DiGraph();
		d.addNode(1, "f");
		d.addNode(3, "s");
		d.addNode(7, "t");
		d.addNode(0, "fo");
		d.addNode(4, "fi");
		d.addNode(6, "si");
		d.addEdge(0, "f", "s", 0, null);
		d.addEdge(1, "f", "si", 0, null);
		d.addEdge(2, "s", "t", 0, null);
		d.addEdge(3, "fo", "fi", 0, null);
		d.addEdge(4, "fi", "si", 0, null);
		System.out.println("numEdges: " + d.numEdges());
		System.out.println("numNodes: " + d.numNodes());
		// printTOPO(d.topoSort());

	}

	public static void printTOPO(String[] toPrint) {
		System.out.print("TOPO Sort: ");
		for (String string : toPrint) {
			System.out.print(string + " ");
		}
		System.out.println();
	}

}
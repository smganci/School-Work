package DiGraph_A5;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.PriorityQueue;

public class DiGraph implements DiGraphInterface {

	Map<String, Node> _nodes;
	Map<Long, Edge> _edges;
	Set<Long> _nodeIds;
	Set<Long> _edgeIds;

	// maybe have a hashmap with node key ids and a list of edges as values
	// then have a map of edges and ins and outs

	// in here go all your data and methods for the graph
	// and the topo sort operation

	// does this have to be empty????
	public DiGraph() { // default constructor
		// explicitly include this
		// we need to have the default constructor
		// if you then write others, this one will still be there
		_nodes = new HashMap<String, Node>();
		_edges = new HashMap<Long, Edge>();
		_nodeIds = new HashSet<Long>();
		_edgeIds = new HashSet<Long>();
	}

	public DiGraph(Map<String, Node> nodes, Map<Long, Edge> edges, Set<Long> nodeIds, Set<Long> edgeIds) {
		_nodes = nodes;
		_edges = edges;
		_nodeIds = nodeIds;
		_edgeIds = edgeIds;
	}

	@Override
	public boolean addNode(long idNum, String label) {
		// false if label is null
		if (label == null) {
			return false;
		}

		// false if label is in the nodes map already
		if (_nodes.containsKey(label)) {
			return false;
		}

		// false if idNum is <0
		if (idNum < 0) {
			return false;
		}

		// false if addded is false bc that would mean the id is already in the
		// set

		if (_nodeIds.contains(idNum)) {
			return false;
		}

		_nodeIds.add(idNum);
		Node node = new Node(idNum, label);
		_nodes.put(label, node);
		return true;

	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {

		if (idNum < 0) {
			return false;
		}

		if (sLabel == null || dLabel == null) {// if labels are null
			return false;
		}

		if (!_nodes.containsKey(sLabel) || !_nodes.containsKey(dLabel)) {// if
			return false;
		}

		Node source = _nodes.get(sLabel);
		Node destination = _nodes.get(dLabel);

		if (source.getOutEdges().containsKey(destination) || destination.getInEdges().containsKey(source)) {
			return false;
		}

		// false if edge id is not unique
		// dont add idNum to set unless were sure we need to add it

		if (_edgeIds.contains(idNum)) {
			return false;
		}

		Edge e = new Edge(idNum, source, destination, weight, eLabel);
		_edges.put(idNum, e);
		_edgeIds.add(idNum);

		return true;

	}

	@Override
	public boolean delNode(String label) {
		if (!_nodes.containsKey(label)) {
			return false;
		}

		Node node = _nodes.get(label);

		Map<Node, Edge> inEdges = node.getInEdges();
		Map<Node, Edge> outEdges = node.getOutEdges();

		for (Node n : inEdges.keySet()) {
			this.delEdge(n.getLabel(), label);
		}

		for (Node n : outEdges.keySet()) {
			this.delEdge(label, n.getLabel());
		}

		// List<Node> out = node.getOuts();
		// List<Node> in = node.getIns();
		//
		// for (int j = 0; j < out.size(); j++) {
		// this.delEdge(node.getLabel(), out.get(j).getLabel());
		// }
		//
		// for (int j = 0; j < in.size(); j++) {
		// this.delEdge(in.get(j).getLabel(), node.getLabel());
		// }

		_nodeIds.remove(node.getId());
		_nodes.remove(label);

		return true;
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {

		// if (sLabel == null || dLabel == null) {
		// return false;
		// }

		if (!_nodes.containsKey(dLabel) || !_nodes.containsKey(sLabel)) {
			return false;
		}

		Node source = _nodes.get(sLabel);
		Node destination = _nodes.get(dLabel);

		if (!source.getOutEdges().containsKey(destination) || !destination.getInEdges().containsKey(source)) {
			return false;
		}

		Edge removed = source.getOutEdges().get(destination);
		long remId = removed.getId();
		_edges.remove(remId);
		_edgeIds.remove(remId);
		source.removeOutEdge(destination);
		destination.removeInEdge(source);

		return true;
	}

	@Override
	public long numNodes() {
		return (long) _nodes.size();
	}

	@Override
	public long numEdges() {
		return (long) _edges.size();
	}

	@Override
	public String[] topoSort() {
		// return null;

		// DiGraph sort = new DiGraph(_nodes, _edges, _nodeIds, _edgeIds);
		String[] topo = new String[_nodes.size()];

		List<Node> q = new ArrayList<Node>();

		for (String s : _nodes.keySet()) {
			Node n = _nodes.get(s);
			if (n.getInDegree() == 0) {
				q.add(n);
			}
		}

		int size = _nodes.size();
		Node fn;
		int i = 0;
		while (q.size() > 0) {
			fn = q.get(0);
			topo[i] = fn.getLabel();

			Set<Node> adj = fn.getAdjacentNodes();

			List<Node> out = fn.getOuts();
			List<Node> in = fn.getIns();
			// // for (Node n : fn.getInEdges().keySet()) {
			// // in.add(n);
			// // // this.delEdge(n.getLabel(), fn.getLabel());
			// // }
			// //
			// // for (Node n : fn.getOutEdges().keySet()) {
			// // out.add(n);
			// // // this.delEdge(fn.getLabel(), n.getLabel());
			// // }

			for (int j = 0; j < out.size(); j++) {
				this.delEdge(fn.getLabel(), out.get(j).getLabel());
			}

			for (int j = 0; j < in.size(); j++) {
				this.delEdge(in.get(j).getLabel(), fn.getLabel());
			}

			this.delNode(fn.getLabel());
			q.remove(0);
			// this.addZero(q, adj);

			for (Node n : adj) {
				if (n.getInDegree() == 0) {
					q.add(n);
					// break;
				}
			}

			i++;
		}

		if (i != size) {
			// System.out.println("cycle");
			return null;
		}

		return topo;

	}

	private void addZero(List<Node> q, Set<Node> adj) {

		for (Node n : adj) {
			if (n.getInDegree() == 0) {
				q.add(n);
				break;
			}
		}

	}

	// rest of your code to implement the various operations
}
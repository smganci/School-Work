package DiGraph_A5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Node {

	// private Map<String, Node> _inNodes;
	// private Map<String, Node> _outNodes;
	//
	private Map<Node, Edge> _inEdges;
	private Map<Node, Edge> _outEdges;// contains edge where current node is the
										// source and node key is dest
	private List<Node> _ins;
	private List<Node> _outs;

	private long _id;
	private String _label;

	public Node(long id, String label) {
		_label = label;
		_id = id;
		// _inNodes = new HashMap<String, Node>();
		// _outNodes = new HashMap<String, Node>();
		_inEdges = new HashMap<Node, Edge>();
		_outEdges = new HashMap<Node, Edge>();
		_ins = new ArrayList<Node>();
		_outs = new ArrayList<Node>();
	}

	public int getInDegree() {
		return _inEdges.size();

	}

	public int getOutDegree() {
		return _outEdges.size();
	}

	public String getLabel() {
		return _label;
	}

	// getting setting and adding in and out edges

	public Map<Node, Edge> getInEdges() {
		return _inEdges;
	}

	public Map<Node, Edge> getOutEdges() {
		return _outEdges;
	}

	public void addInEdge(Edge e, Node n) {
		_inEdges.put(n, e);
		_ins.add(n);
	}

	public void addOutEdge(Edge e, Node n) {
		_outEdges.put(n, e);
		_outs.add(n);
	}

	public void removeOutEdge(Node n) {
		_outEdges.remove(n);
		_outs.remove(n);
	}

	public void removeInEdge(Node n) {
		_inEdges.remove(n);
		_ins.remove(n);
	}

	public long getId() {
		return _id;
	}

	public Set<Node> getAdjacentNodes() {
		Set<Node> adj = new HashSet<Node>();
		for (Node n : _inEdges.keySet()) {
			adj.add(n);
		}

		for (Node n : _outEdges.keySet()) {
			adj.add(n);
		}
		return adj;
	}

	public List<Node> getIns() {
		return _ins;
	}

	public List<Node> getOuts() {
		return _outs;
	}

}

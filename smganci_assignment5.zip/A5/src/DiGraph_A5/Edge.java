package DiGraph_A5;

public class Edge {

	private Node _source;
	private Node _destination;
	private long _id;
	private long _weight;
	private String _label;

	public Edge(long id, Node source, Node destination, long weight, String label) {
		_source = source;
		_destination = destination;
		_id = id;
		_weight = weight;
		_label = label;

		// add edge to sources out edge
		// edd edge to destination in edges

		_source.addOutEdge(this, _destination);
		_destination.addInEdge(this, _source);
	}

	public Node getSource() {
		return _source;
	}

	public void setSource(Node source) {
		this._source = source;
	}

	public Node getDestination() {
		return _destination;
	}

	public void setDestination(Node destination) {
		this._destination = destination;
	}

	public long getId() {
		return _id;
	}

	public long getWeight() {
		return _weight;
	}

	public String getLabel() {
		return _label;
	}

}

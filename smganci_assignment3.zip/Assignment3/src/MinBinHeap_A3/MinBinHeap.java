package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; // load this array
	private int size;
	private static final int arraySize = 10000; // Everything in the array will
												// initially
												// be null. This is ok! Just
												// build out
												// from array[1]

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); // 0th will be unused for
													// simplicity
													// of child/parent
													// computations...
													// the book/animation page
													// both do this.
	}

	// Please do not remove or modify this method! Used to test your entire
	// Heap.
	@Override
	public EntryPair[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {

		int hole = size + 1;

		// keep swapping up the hole while the priority of the entry is less
		// than the priority of the current parent
		for (array[0] = entry; entry.getPriority() < array[hole / 2].getPriority(); hole /= 2) {
			// set the array at the hole to be the value of the parent
			array[hole] = array[hole / 2];
			// then hole=hole/2 so hole=parent
		}

		array[hole] = entry;

		size++;

	}

	@Override
	public void delMin() {
		/*
		 * step1: make a hole at the root step2: get the last thing which will
		 * be at array[size]; step3: bubble down that hole till the hole is at a
		 * place where the priority of the last item is okay
		 */
		if (size != 0) {

			array[1] = array[size];
			array[size] = null;
			size--;

			// percolate depends on size so decrement before
			this.percolateDown(1);

		}

	}

	@Override
	public EntryPair getMin() {
		// TODO Auto-generated method stub
		return array[1];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {

		// first put entries in array

		array = new EntryPair[arraySize];

		for (int i = 0; i < entries.length; i++) {
			array[i + 1] = entries[i];
		}

		size = entries.length;

		for (int i = size / 2; i > 0; i--) {
			this.percolateDown(i);
		}

		// then sort the array

	}

	public EntryPair getLeftChild(int i) {
		return array[i * 2];
	}

	public EntryPair getRightChild(int i) {
		return array[(i * 2) + 1];
	}

	public EntryPair getParent(int i) {
		return array[i / 2];
	}

	public void percolateDown(int hole) {

		EntryPair temp = array[hole];
		int child;

		for (; hole * 2 <= size; hole = child) {
			child = hole * 2;

			if (child != size && array[child + 1].getPriority() < array[child].getPriority()) {
				child++;
			}

			if (array[child].getPriority() < temp.getPriority()) {
				array[hole] = array[child];
			} else {
				break;
			}
		}

		array[hole] = temp;

		// my way
		// EntryPair temp = array[hole];
		// int child;
		// while (hole * 2 <= size) {
		// child = hole * 2;
		//
		// // if its not the last and only child and if the right child
		// // (array[chilr+1] has a lower priority than the current child then
		// // up the child index
		// if (child != size && array[child + 1].getPriority() <
		// array[child].getPriority()) {
		// child++;
		// }
		//
		// // if the child has a lower priority value than the hole then you
		// // want to swap the child with the hole
		// if (array[child].getPriority() < array[hole].getPriority()) {
		// array[hole] = array[child];
		// } else {
		// // if not that means that the child has a larger priority than
		// // the hole, which is what you want so break
		// break;
		// }
		//
		// // if you havent broken out of the loop, make the hole equal the
		// // child
		//
		// hole = child;

		// array[hole] = temp;

	}

}
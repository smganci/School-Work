package A6_Dijkstra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Vertex {

	// private Map<String, Node> _inNodes;
	// private Map<String, Node> _outNodes;
	//
	private Map<Vertex, Edge> _inEdges;
	private Map<Vertex, Edge> _outEdges;// contains edge where current node is
										// the
										// source and node key is dest
	private List<Vertex> _ins;
	private List<Vertex> _outs;

	private long _id;
	private String _label;

	private boolean _handled;
	private long _dist;
	private Vertex _path;

	public Vertex(long id, String label) {
		_label = label;
		_id = id;
		// _inNodes = new HashMap<String, Node>();
		// _outNodes = new HashMap<String, Node>();
		_inEdges = new HashMap<Vertex, Edge>();
		_outEdges = new HashMap<Vertex, Edge>();
		_ins = new ArrayList<Vertex>();
		_outs = new ArrayList<Vertex>();

		_handled = false;
		_dist = Long.MAX_VALUE;
		_path = null;
	}

	public Vertex getPath() {
		return _path;
	}

	public void setPath(Vertex path) {
		_path = path;
	}

	public long getDist() {
		return _dist;
	}

	public void setDist(long dist) {
		_dist = dist;
	}

	public boolean getHandled() {
		return _handled;
	}

	public void setHandled(boolean handled) {
		_handled = handled;
	}

	public int getInDegree() {
		return _inEdges.size();

	}

	public int getOutDegree() {
		return _outEdges.size();
	}

	public String getLabel() {
		return _label;
	}

	// getting setting and adding in and out edges

	public Map<Vertex, Edge> getInEdges() {
		return _inEdges;
	}

	public Map<Vertex, Edge> getOutEdges() {
		return _outEdges;
	}

	public void addInEdge(Edge e, Vertex n) {
		_inEdges.put(n, e);
		_ins.add(n);
	}

	public void addOutEdge(Edge e, Vertex n) {
		_outEdges.put(n, e);
		_outs.add(n);
	}

	public void removeOutEdge(Vertex n) {
		_outEdges.remove(n);
		_outs.remove(n);
	}

	public void removeInEdge(Vertex n) {
		_inEdges.remove(n);
		_ins.remove(n);
	}

	public long getId() {
		return _id;
	}

	public Set<Vertex> getAdjacentNodes() {
		Set<Vertex> adj = new HashSet<Vertex>();
		for (Vertex n : _inEdges.keySet()) {
			adj.add(n);
		}

		for (Vertex n : _outEdges.keySet()) {
			adj.add(n);
		}
		return adj;
	}

	public List<Vertex> getIns() {
		return _ins;
	}

	public List<Vertex> getOuts() {
		return _outs;
	}

}

package A6_Dijkstra;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.PriorityQueue;

public class DiGraph implements DiGraph_Interface {

	private Map<String, Vertex> _vertices;
	private Map<Long, Edge> _edges;
	private Set<Long> _vertIds;
	private Set<Long> _edgeIds;

	public DiGraph() { // default constructor
		// explicitly include this
		// we need to have the default constructor
		// if you then write others, this one will still be there
		_vertices = new HashMap<String, Vertex>();
		_edges = new HashMap<Long, Edge>();
		_vertIds = new HashSet<Long>();
		_edgeIds = new HashSet<Long>();

	}

	public DiGraph(Map<String, Vertex> nodes, Map<Long, Edge> edges, Set<Long> nodeIds, Set<Long> edgeIds) {
		_vertices = nodes;
		_edges = edges;
		_vertIds = nodeIds;
		_edgeIds = edgeIds;
	}

	@Override
	public boolean addNode(long idNum, String label) {
		// false if label is null
		if (label == null) {
			return false;
		}

		// false if label is in the nodes map already
		if (_vertices.containsKey(label)) {
			return false;
		}

		// false if idNum is <0
		if (idNum < 0) {
			return false;
		}

		// false if addded is false bc that would mean the id is already in the
		// set

		if (_vertIds.contains(idNum)) {
			return false;
		}

		_vertIds.add(idNum);
		Vertex node = new Vertex(idNum, label);
		_vertices.put(label, node);
		return true;

	}

	@Override
	public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {

		if (idNum < 0) {
			return false;
		}

		if (sLabel == null || dLabel == null) {// if labels are null
			return false;
		}

		if (!_vertices.containsKey(sLabel) || !_vertices.containsKey(dLabel)) {// if
			return false;
		}

		Vertex source = _vertices.get(sLabel);
		Vertex destination = _vertices.get(dLabel);

		if (source.getOutEdges().containsKey(destination) || destination.getInEdges().containsKey(source)) {
			return false;
		}

		// false if edge id is not unique
		// dont add idNum to set unless were sure we need to add it

		if (_edgeIds.contains(idNum)) {
			return false;
		}

		Edge e = new Edge(idNum, source, destination, weight, eLabel);
		_edges.put(idNum, e);
		_edgeIds.add(idNum);

		return true;

	}

	@Override
	public boolean delNode(String label) {
		if (!_vertices.containsKey(label)) {
			return false;
		}

		Vertex node = _vertices.get(label);

		Map<Vertex, Edge> inEdges = node.getInEdges();
		Map<Vertex, Edge> outEdges = node.getOutEdges();

		for (Vertex n : inEdges.keySet()) {
			this.delEdge(n.getLabel(), label);
		}

		for (Vertex n : outEdges.keySet()) {
			this.delEdge(label, n.getLabel());
		}

		_vertIds.remove(node.getId());
		_vertices.remove(label);

		return true;
	}

	@Override
	public boolean delEdge(String sLabel, String dLabel) {

		if (!_vertices.containsKey(dLabel) || !_vertices.containsKey(sLabel)) {
			return false;
		}

		Vertex source = _vertices.get(sLabel);
		Vertex destination = _vertices.get(dLabel);

		if (!source.getOutEdges().containsKey(destination) || !destination.getInEdges().containsKey(source)) {
			return false;
		}

		Edge removed = source.getOutEdges().get(destination);
		long remId = removed.getId();
		_edges.remove(remId);
		_edgeIds.remove(remId);
		source.removeOutEdge(destination);
		destination.removeInEdge(source);

		return true;
	}

	@Override
	public long numNodes() {
		return (long) _vertices.size();
	}

	@Override
	public long numEdges() {
		return (long) _edges.size();
	}

	@Override
	public String[] topoSort() {
		String[] topo = new String[_vertices.size()];

		List<Vertex> q = new ArrayList<Vertex>();

		for (String s : _vertices.keySet()) {
			Vertex n = _vertices.get(s);
			if (n.getInDegree() == 0) {
				q.add(n);
			}
		}

		int size = _vertices.size();
		Vertex fn;
		int i = 0;
		while (q.size() > 0) {
			fn = q.get(0);
			topo[i] = fn.getLabel();

			Set<Vertex> adj = fn.getAdjacentNodes();

			List<Vertex> out = fn.getOuts();
			List<Vertex> in = fn.getIns();

			for (int j = 0; j < out.size(); j++) {
				this.delEdge(fn.getLabel(), out.get(j).getLabel());
			}

			for (int j = 0; j < in.size(); j++) {
				this.delEdge(in.get(j).getLabel(), fn.getLabel());
			}

			this.delNode(fn.getLabel());
			q.remove(0);

			for (Vertex n : adj) {
				if (n.getInDegree() == 0) {
					q.add(n);
				}
			}

			i++;
		}

		if (i != size) {
			return null;
		}

		return topo;

	}

	@Override
	public ShortestPathInfo[] shortestPath(String label) {
		if (!_vertices.containsKey(label)) {
			return null;
		}
		EntryPair source = new EntryPair(label, 0);

		MinBinHeap pq = new MinBinHeap();

		pq.insert(source);
		_vertices.get(label).setDist(0);

		while (pq.size() > 0) {
			// deleted min is current vertex
			EntryPair min = pq.getMin();
			String curr = min.getValue();
			pq.delMin();
			Vertex current = _vertices.get(curr);

			if (current.getHandled()) {
				continue;
			}
			current.setHandled(true);

			// visit all the outedges of the current vertex
			Map<Vertex, Edge> outs = current.getOutEdges();
			for (Vertex v : outs.keySet()) {

				// if it has already been handled/finalized and removed from the
				// queue we dont want to do anything
				if (!v.getHandled()) {
					Edge e = outs.get(v);
					long edgeWeight = e.getWeight();
					long plen = current.getDist() + edgeWeight;
					if (plen < v.getDist()) {
						// distances.put(v, plen);
						// parents.put(v, current);
						v.setDist(plen);
						v.setPath(current);
						pq.insert(new EntryPair(v.getLabel(), plen));
					}
					// if the item is already in the pq, we dont want to add it
					// again
					// but how do you change the priority????
				}

			}
		}

		ShortestPathInfo[] shorty = new ShortestPathInfo[(int) numNodes()];
		int i = 0;

		for (String s : _vertices.keySet()) {
			long weight;
			Vertex current = _vertices.get(s);
			if (current.getPath() == null) {
				if (s.equals(label)) {
					weight = 0;
				} else {
					weight = -1;
				}
			} else {
				weight = current.getDist();
			}
			shorty[i] = new ShortestPathInfo(s, weight);
			i++;
		}

		return shorty;

	}

	// public ShortestPathInfo[] shortestPath1(String label) {
	//
	// // var sNode; // source node number
	// EntryPair source = new EntryPair(label, 0);
	//
	// // var edge, n, ob; // temps
	// Edge edge;
	// String v;
	// EntryPair ob;
	//
	// // var pq = makePriorityQueue(); // priority queue for best performance
	// MinBinHeap p = new MinBinHeap();
	// int plen;
	// //
	// // for (var i=0; i<G.nnum; i++) { // init all nodes path and dist
	// // G.nodes[i].path=Infinity;
	// // G.nodes[i].dist=Infinity;
	// // G.nodes[i].handled=false;
	// // }
	//
	// //
	// // G.nodes[sNode].dist = 0; // shortest path source to source is 0
	// // pq.insert(0,sNode); // put source node num on queue to get ball
	// // rolling
	//
	// p.insert(source);
	// //
	// // while (pq.size() > 0) {
	// while (p.size() > 0) {
	// // // process the min node on the heap
	// // ob = pq.getMin(); pq.delMin();
	// ob = p.delMin();
	// // n = ob.val;
	// v = ob.getValue();
	// // if (G.nodes[n].handled) { continue; } // might be in pq from
	// // earlier pathlengt
	// Vertex current = _vertices.get(v);
	// if (current.getHandled()) {
	// continue;
	// }
	// // G.nodes[n].handled = true;
	// current.setHandled(true);
	// // edge = G.nodes[n].adj; // deal with out edge nodes if any
	// Map<Vertex, Edge> outs = current.getOutEdges();
	//
	// // while (edge!==null) {
	// for (Vertex vertex : outs.keySet()) {
	//
	// Edge e = outs.get(vertex);
	// // if (!G.nodes[edge.tn].handled) { // dont process if we have
	// // already done it
	//
	// if (!vertex.getHandled()) {
	// // pLen = G.nodes[n].dist + edge.weight;
	// plen = (int) (current.getDist() + e.getWeight());
	//
	// if (plen < vertex.getDist()) {
	// // if (pLen < G.nodes[edge.tn].dist) {
	// // // update distance for dest node
	// // G.nodes[edge.tn].dist = pLen;
	// vertex.setDist(plen);
	// // G.nodes[edge.tn].path = n;
	// vertex.setPath(current);
	// // pq.insert(pLen,edge.tn);
	// p.insert(new EntryPair(vertex.getLabel(), plen));
	// // }
	//
	// }
	// }
	//
	// }
	//
	// }
	//
	// // p.insert(source);
	//
	// // while (p.size() > 0) {
	// //
	// // int path = 0;
	// // EntryPair entry = p.delMin();
	// // Vertex curr = _vertices.get(entry.getValue());
	// // Map<Vertex, Edge> outs = curr.getOutEdges();
	// // for (Vertex v : outs.keySet()) {
	// //
	// // Edge edgeToV = outs.get(v);
	// // int weight = (int) edgeToV.getWeight();
	// // int newPath = path + weight;
	// // EntryPair fringe = new EntryPair(v.getLabel(), newPath);
	// // }
	// // }
	//
	// // start by adding the start to the queue
	// // then dequeue and add the adjacent ones to the queue
	// //
	//
	// ShortestPathInfo[] shorty = new ShortestPathInfo[(int) numNodes()];
	// int i = 0;
	//
	// for (String s : _vertices.keySet()) {
	//
	// long weight;
	//
	// Vertex current = _vertices.get(s);
	//
	// if (current.getPath() == null) {
	// weight = -1;
	// } else {
	// weight = current.getDist();
	// }
	//
	// shorty[i] = new ShortestPathInfo(s, weight);
	//
	// i++;
	//
	// }
	//
	// return shorty;
	//
	// }

	// rest of your code to implement the various operations
}
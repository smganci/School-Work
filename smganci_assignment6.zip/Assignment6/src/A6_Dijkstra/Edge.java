package A6_Dijkstra;

public class Edge {

	private Vertex _source;
	private Vertex _destination;
	private long _id;
	private long _weight;
	private String _label;

	public Edge(long id, Vertex source, Vertex destination, long weight, String label) {
		_source = source;
		_destination = destination;
		_id = id;
		_weight = weight;
		_label = label;

		// add edge to sources out edge
		// edd edge to destination in edges

		_source.addOutEdge(this, _destination);
		_destination.addInEdge(this, _source);
	}

	public Vertex getSource() {
		return _source;
	}

	public void setSource(Vertex source) {
		this._source = source;
	}

	public Vertex getDestination() {
		return _destination;
	}

	public void setDestination(Vertex destination) {
		this._destination = destination;
	}

	public long getId() {
		return _id;
	}

	public long getWeight() {
		return _weight;
	}

	public String getLabel() {
		return _label;
	}

}

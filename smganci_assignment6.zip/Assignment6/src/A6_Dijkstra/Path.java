package A6_Dijkstra;

public class Path {

	private Vertex vert;
	private long dist;
	private Path path;
	private boolean handled;

	public Path(Vertex v) {
		vert = v;
		handled = false;
		dist = Long.MAX_VALUE;
	}

	public Vertex getVert() {
		return vert;
	}

	public void setVert(Vertex vert) {
		this.vert = vert;
	}

	public long getDist() {
		return dist;
	}

	public void setDist(long dist) {
		this.dist = dist;
	}

	public Path getPath() {
		return path;
	}

	public void setPath(Path path) {
		this.path = path;
	}

	public void setHandled(boolean h) {
		handled = false;
	}

}

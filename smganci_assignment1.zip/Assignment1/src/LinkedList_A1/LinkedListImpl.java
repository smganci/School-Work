/**
 * COMP 410
 *See inline comment descriptions for methods not described in interface.
 *
*/
package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
	Node root;// this will be the entry point to your linked list (the head)

	int size = 0;

	public LinkedListImpl() {// this constructor is needed for testing purposes.
								// Please don't modify!
		root = new Node(0); // Note that the root's data is not a true part of
							// your data set!
		size = 0;
	}

	// implement all methods in interface, and include the getRoot method we
	// made for testing purposes. Feel free to implement private helper methods!

	public Node getRoot() { // leave this method as is, used by the grader to
							// grab your linkedList easily.
		return root;
	}

	@Override
	public boolean insert(Node n, int index) {
		// note to self: we could want to insert at index=size because that is
		// the end

		if (n == null) {
			return false;
		}
		if (index < 0 || index > size) {
			return false;
		}

		if (index == 0) {
			// if you want to add one in the beginning
			if (isEmpty()) {
				root.next = n;
			} else {
				Node newNext = root.next;
				root.next = n;
				n.next = newNext;
			}

		} else if (index == size) {
			// if you want to add one on the end
			Node beforeN = get(index - 1);
			beforeN.next = n;

		} else {
			Node beforeN = get(index - 1);
			Node currentAtIndex = get(index);

			beforeN.next = n;
			n.next = currentAtIndex;
		}

		size++;

		return true;
	}

	@Override
	public boolean remove(int index) {
		if (index < 0 || index >= size) {
			return false;
		}

		if (index == 0) {
			if (isEmpty()) {
				return false;
			} else {
				Node remove = root.next;
				Node newNext = remove.next;
				root.next = newNext;

			}

		} else if (index == size - 1) {
			Node newLast = get(index - 1);
			newLast.next = null;

		} else {

			Node before = get(index - 1);
			Node after = get(index + 1);
			before.next = after;

		}

		size--;

		return true;
	}

	@Override
	public Node get(int index) {

		// thoughts get the one at the index and for ones where Im inserting or
		// removing use -1 to like reset stuff
		if (index >= size || index < 0) {
			return null;
		}

		Node node = root;

		for (int i = 0; i <= index; i++) {
			node = node.getNext();
		}

		return node;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return size == 0;
	}

	@Override
	public void clear() {
		root.next = null;
		size = 0;

	}
}
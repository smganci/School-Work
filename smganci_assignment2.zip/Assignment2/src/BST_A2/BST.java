package BST_A2;

public class BST implements BST_Interface {
	public BST_Node root;
	int size;

	public BST() {
		size = 0;
		root = null;
	}

	@Override
	// used for testing, please leave as is
	public BST_Node getRoot() {
		return root;
	}

	@Override
	public boolean insert(String s) {
		// TODO Auto-generated method stub
		boolean inserted = false;

		if (root == null) {
			root = new BST_Node(s);
			inserted = true;
		} else {
			if (!contains(s)) {
				root.insertNode(s);
				inserted = true;
			}
		}

		if (inserted) {
			size++;
		}

		return inserted;
	}

	@Override
	public boolean remove(String s) {
		// TODO Auto-generated method stub

		if (empty()) {
			return false;
		}

		// deleting the root is a special case
		if (root.data.compareTo(s) == 0) {
			if (size == 1) {
				// if size is one then all you need to do is make the root null
				// and decrease size
				root = null;

				size--;
				return true;
			} else {
				// make a dummy root and add root as its left child
				BST_Node dummy = new BST_Node(null);
				dummy.left = root;
				// make the new root the dummy root
				root = dummy.left;

				// then call remove on the new root
				root.removeNode(dummy, s);

				// dec size
				size--;
				return true;

			}

		} else {

			// remove node from root (have to pass in null as parent because you
			// cant pass in root--recursion takes care of it
			root.removeNode(null, s);

			size--;
			return true;

		}

	}

	@Override
	public String findMin() {
		// if empty no need to search
		if (empty()) {
			return null;
		}
		// delegate
		return root.findMin().getData();

	}

	@Override
	public String findMax() {
		// if empty no need to search
		if (empty()) {
			return null;
		}
		// delegate
		return root.findMax().getData();
	}

	@Override
	public boolean empty() {
		// if size is zero, tree is empty
		return size == 0;
	}

	@Override
	public boolean contains(String s) {
		// if its empty then no need to search
		if (empty()) {
			return false;
		}
		// delegate
		return root.containsNode(s);
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public int height() {
		if (empty()) {
			return -1;
		}

		if (size == 1) {
			return 0;
		}

		return root.getHeight(root);
	}

}
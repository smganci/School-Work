package BST_A2;

public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;

	BST_Node(String data) {
		this.data = data;
	}

	// --- used for testing ----------------------------------------------
	//
	// leave these 3 methods in, as is

	public String getData() {
		return data;
	}

	public BST_Node getLeft() {
		return left;
	}

	public BST_Node getRight() {
		return right;
	}

	// --- end used for testing -------------------------------------------

	// --- fill in these methods ------------------------------------------
	//
	// at the moment, they are stubs returning false
	// or some appropriate "fake" value
	//
	// you make them work properly
	// add the meat of correct implementation logic to them

	// you MAY change the signatures if you wish...
	// make the take more or different parameters
	// have them return different types
	//
	// you may use recursive or iterative implementations

	public boolean containsNode(String s) {
		// to break out of recursive call we will either reacha null and return
		// false or the String s and return true

		int compare = s.compareTo(data);

		// key for self:
		// -1 means that s occurs before data
		// 0 means that s and data are equal
		// 1 means that s occurs after data

		if (compare == 0) {
			// match so return true
			return true;
		} else if (compare < 0) {
			// s is less than data
			if (left == null) {
				// nothing left to search so return false
				return false;
			} else {
				// recursively search in left child
				return left.containsNode(s);
			}
		} else {
			// s is greater than data
			if (right == null) {
				// nothing left in right to search so return false
				return false;
			} else {
				// recursively search right node
				return right.containsNode(s);
			}
		}
	}

	public boolean insertNode(String s) {
		// below code might make everything super slow--compensated by adding
		// checks in bst and adding return false statements
		// if(containsNode(s)){
		// return true;
		// }

		int compare = s.compareTo(data);

		// To Self: left and right refer to the current nodes left and right

		// key for self:
		// -1 means that s occurs before data
		// 0 means that s and data are equal
		// 1 means that s occurs after data

		if (compare == 0) {
			// if it already exists, we don't/can't insert and return false
			return false;
		} else if (compare < 0) {
			if (left == null) {
				// if left is null then the current nodes left becomes a new
				// BST_Node with s as data
				left = new BST_Node(s);
				return true;
			} else {
				// if left is not null, then we recursively call insertNode on
				// left
				return left.insertNode(s);
			}
		} else {
			if (right == null) {
				// if right is null, new bst node of s goes here and we return
				// true
				right = new BST_Node(s);
				return true;
			} else {
				// if right is not null we recursively call insert on the right
				// child of the current node
				return right.insertNode(s);
			}
		}

	}

	public boolean removeNode(BST_Node parent, String s) {

		int compare = s.compareTo(data);

		if (compare < 0) {
			if (left == null) {
				// return false if s is less than the current nodes data, but
				// left is null bc it cant exist
				return false;

			} else {
				// recursively call remove on left node
				return left.removeNode(this, s);
			}
		} else if (compare > 0) {
			if (right == null) {
				// returns false when s is greater than value of data and would
				// happen in the right part of the tree, but there is no right
				// so it cant exist
				return false;
			} else {
				// recursive call to keep searching
				return right.removeNode(this, s);
			}
		} else {
			// this would happen if compare value is 0, and therefore a match

			if (this.left != null && this.right != null) {
				// 2 children
				// Strategy: find new median leaf by getting the min value of
				data = right.findMin().data;
				right.removeNode(this, right.findMin().data);

			} else if (parent.left == this) {
				// if the current node is the left child of the parent node that
				// we passed in, then we need to reassign the parents left to be
				// the current nodes left or right child depending on which of
				// the current nodes children is null

				// old, slow, not fancy way:
				// if(left==null){
				// parent.left=right;
				// }else{
				// parent.left=left;
				// }

				// book uses ternary(?) operator
				//
				parent.left = (left != null) ? left : right;
			} else if (parent.right == this) {

				// old way
				// if(right==null){
				// parent.right=left;
				// }else{
				// parent.right=right;
				// }

				parent.right = (left != null) ? left : right;
			}

			return true;

		}

	}

	public BST_Node findMin() {

		// base case checks to see if the left of the current node is null and
		// if it is then the current node is the left most node and therefore
		// the smallest
		if (left == null) {
			return this;
		} else {
			// recursively call find min on the left node of the current node
			// will eventuall stop at base case when the next left is null
			return left.findMin();
		}

	}

	public BST_Node findMax() {

		// base case checks to see if right of current node is null, if it is,
		// return the current node because it is the most right node and
		// therefore the largest
		if (right == null) {
			return this;
		} else {
			// recursively call find max on the right child of the current node
			// will eventually stop at base case
			return right.findMax();
		}

	}

	public int getHeight(BST_Node node) {
		// recursively find the max height of the left and right trees and add
		// one
		// when you get to a leaf you don't want to add one, but you will end up
		// doing so because you pass left and right in without checks, so to
		// accomadate to this I have a base case that checks to see if the node
		// passed in is a null, and if it is, you return negative one

		//
		if (node == null) {
			return -1;
		}

		// Math.max will pick the largest one of the left and right
		return 1 + Math.max(getHeight(node.left), getHeight(node.right));

	}

	// --- end fill in these methods --------------------------------------

	// --------------------------------------------------------------------
	// you may add any other methods you want to get the job done
	// --------------------------------------------------------------------

	public String toString() {
		return "Data: " + this.data + ", Left: " + ((this.left != null) ? left.data : "null") + ",Right: "
				+ ((this.right != null) ? right.data : "null");
	}

	// helper method that I didn't even end up using but hey it could be useful
	// oneday maybe
	public boolean isLeaf() {
		if (left == null && right == null) {
			return true;
		} else {
			return false;
		}
	}

	// too bitter to delete my old code--please ignore

	// Below is janky-ass remove method
	// int compare = s.compareTo(data);
	//
	// if (compare == 0) {
	// if (right == null && left == null) {
	// // deal with in bst because you are deleting the root of a size
	// // one tree
	// } else if (right == null && left != null) {
	// BST_Node lchild = left.left;
	// BST_Node rchild = left.right;
	// this.data = left.getData();
	// this.left = lchild;
	// this.right = rchild;
	//
	// } else if (right != null && left == null) {
	// BST_Node lchild = right.left;
	// BST_Node rchild = right.right;
	// this.data = right.data;
	// this.left = lchild;
	// this.right = rchild;
	// } else {
	// BST_Node oldparent = this;
	// BST_Node newParent = right.findMin();
	// removePart(right.findMin().data);
	// oldparent.data = newParent.data;
	// }
	// return true;
	// } else if (compare < 0) {
	// // check left to see if its equal
	// if (s.compareTo(left.data) == 0) {
	// // if it is equal we need to check for childrens
	//
	// if (left.left == null && left.right == null) {
	// left = null;
	//
	// } else if (left.right == null) {
	// left = left.left;
	//
	// } else if (left.left == null) {
	// left = left.right;
	//
	// } else {
	// // old node is current left
	// BST_Node oldParent = left;
	// BST_Node lchild = left.left;
	// BST_Node rchild = left.right;
	//
	// // the replacement will be the left nodes right nodes min
	// // node
	// // check to see if left.right is the min?
	// BST_Node newParent = left.right.findMin();
	//
	// // now we need to get rid of the left right min which we
	// // could do by calling remove because we know that it can be
	// // handled
	// removePart(left.right.findMin().data);
	//
	// left = newParent;
	// newParent.left = lchild;
	// newParent.right = rchild;
	//
	// }
	// return true;
	//
	// } else {
	// return left.removeNode(s);
	// }
	//
	// } else {
	// if (s.compareTo(right.data) == 0) {
	// // if it is equal we need to check for childrens
	//
	// if (right.left == null && right.right == null) {
	// right = null;
	//
	// } else if (right.right == null) {
	// right = right.left;
	//
	// } else if (right.left == null) {
	// right = right.right;
	//
	// } else {
	// // old node is current left
	// BST_Node oldParent = right;
	// BST_Node lchild = right.left;
	// BST_Node rchild = right.right;
	//
	// // the replacement will be the left nodes right nodes min
	// // node
	// // check to see if left.right is the min?
	// BST_Node newParent = right.right.findMin();
	//
	// // now we need to get rid of the right rich min which we
	// // could do by calling remove because we know that it can be
	// // handled
	// removePart(right.right.findMin().data);
	//
	// right = newParent;
	// newParent.left = lchild;
	// newParent.right = rchild;
	//
	// }
	// return true;
	//
	// } else {
	// return right.removeNode(s);
	// }
	// }
}
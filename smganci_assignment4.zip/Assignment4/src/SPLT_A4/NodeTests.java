package SPLT_A4;

public class NodeTests {

	public static void main(String[] args) {
		// testZig(); //works

		// testZigZag(); //works

		// testRemove(); //works
		testSplay();

	}

	public static void testSplay() {
		BST_Node orange = new BST_Node("orange");
		orange.insertNode("banana");
		orange.insertNode("zebra");
		orange.insertNode("pop");
		orange.insertNode("zzzz");
		orange.insertNode("apple");
		orange.insertNode("aard");
		orange.insertNode("art");
		orange.insertNode("brat");
		orange.insertNode("beet");
		orange.insertNode("car");

		BST_Node banana = orange.getLeft();
		BST_Node zebra = orange.getRight();
		BST_Node pop = zebra.getLeft();
		BST_Node z = zebra.getRight();
		BST_Node apple = banana.getLeft();
		BST_Node aard = apple.getLeft();
		BST_Node art = apple.getRight();
		BST_Node brat = banana.getRight();
		BST_Node beet = brat.getLeft();
		BST_Node car = brat.getRight();

		System.out.println(orange);
		System.out.println(banana);
		System.out.println(zebra);
		System.out.println(pop);
		System.out.println(z);
		System.out.println(apple);
		System.out.println(aard);
		System.out.println(art);
		System.out.println(brat);
		System.out.println(beet);
		System.out.println(car);

		car.splay();

		System.out.println("after splay of car");
		System.out.println(orange);
		System.out.println(banana);
		System.out.println(zebra);
		System.out.println(pop);
		System.out.println(z);
		System.out.println(apple);
		System.out.println(aard);
		System.out.println(art);
		System.out.println(brat);
		System.out.println(beet);
		System.out.println(car);

	}

	public static void testRemove() {

		BST_Node orange = new BST_Node("orange");
		orange.insertNode("banana");
		orange.insertNode("zebra");
		orange.insertNode("pop");
		orange.insertNode("zzzz");
		orange.insertNode("apple");
		orange.insertNode("aard");
		orange.insertNode("art");
		orange.insertNode("brat");
		orange.insertNode("beet");
		orange.insertNode("car");

		BST_Node banana = orange.getLeft();
		BST_Node zebra = orange.getRight();
		BST_Node pop = zebra.getLeft();
		BST_Node z = zebra.getRight();
		BST_Node apple = banana.getLeft();
		BST_Node aard = apple.getLeft();
		BST_Node art = apple.getRight();
		BST_Node brat = banana.getRight();
		BST_Node beet = brat.getLeft();
		BST_Node car = brat.getRight();

		System.out.println(orange);
		System.out.println(banana);
		System.out.println(zebra);
		System.out.println(pop);
		System.out.println(z);
		System.out.println(apple);
		System.out.println(aard);
		System.out.println(art);
		System.out.println(brat);
		System.out.println(beet);
		System.out.println(car);
		orange.removeNode(brat.data);

		System.out.println("After deletion of brat");
		System.out.println(orange);
		System.out.println(banana);
		System.out.println(zebra);
		System.out.println(pop);
		System.out.println(z);
		System.out.println(apple);
		System.out.println(aard);
		System.out.println(art);
		System.out.println(brat);
		System.out.println(beet);
		System.out.println(car);

	}

	public static void testZigZag() {
		BST_Node orange = new BST_Node("orange");
		orange.insertNode("banana");
		orange.insertNode("zebra");
		orange.insertNode("pop");
		orange.insertNode("zzzz");
		orange.insertNode("apple");
		orange.insertNode("aard");
		orange.insertNode("art");
		orange.insertNode("brat");
		orange.insertNode("beet");
		orange.insertNode("car");

		BST_Node banana = orange.getLeft();
		BST_Node zebra = orange.getRight();
		BST_Node pop = zebra.getLeft();
		BST_Node z = zebra.getRight();
		BST_Node apple = banana.getLeft();
		BST_Node aard = apple.getLeft();
		BST_Node art = apple.getRight();
		BST_Node brat = banana.getRight();
		BST_Node beet = brat.getLeft();
		BST_Node car = brat.getRight();
		brat.zigZagLR();

		System.out.println("ZigZagLR on brat");
		System.out.println(brat);
		System.out.println(banana);
		System.out.println(orange);

		System.out.println("ZigZagRL on car");
		car.zigZagRL();
		System.out.println(car);
		System.out.println(brat);
		System.out.println(orange);
		System.out.println(zebra);
		System.out.println(banana);

	}

	public static void testZig() {
		BST_Node orange = new BST_Node("orange");
		System.out.println(orange);
		orange.insertNode("banana");
		System.out.println("Node after one insert on the left " + orange);

		orange.insertNode("zebra");

		orange.insertNode("pop");

		orange.insertNode("zzzz");

		// node.splay();

		System.out.println("Node after zebra and pop and zzz inserted " + orange);

		BST_Node banana = orange.getLeft();
		System.out.println("banana field: " + banana);

		BST_Node zebra = orange.getRight();
		System.out.println("zebra " + zebra);

		BST_Node pop = zebra.getLeft();
		System.out.println("Pop stuff " + pop);

		BST_Node z = zebra.getRight();
		System.out.println("ZZZ stuff" + z);

		zebra.zigLeft();

		System.out.println("data after zebra zigged left");

		System.out.println(orange);
		System.out.println(zebra);

		orange.zigRight();

		System.out.println("data after organge zigged right");
		System.out.println(orange);
		System.out.println(zebra);

		System.out.println("Insert more values to test zigzig");
		orange.insertNode("apple");
		BST_Node apple = banana.getLeft();

		orange.insertNode("aard");
		BST_Node aard = apple.getLeft();

		orange.insertNode("art");
		BST_Node art = apple.getRight();

		orange.insertNode("brat");
		BST_Node brat = banana.getRight();

		System.out.println("apple " + apple);
		System.out.println("aard " + aard);
		System.out.println("art " + art);
		System.out.println("brat" + brat);

		System.out.println("Zig Zig Right on Apple");

		apple.zigZigRR();

		System.out
				.println("Apples left expected aard; right expected: banana; parent expected: null; actual: " + apple);
		System.out.println(banana);
		System.out.println(orange);

		System.out.println("Zig LL on orange");

		orange.zigZigLL();

		System.out.println(orange);
		System.out.println(banana);
		System.out.println(apple);
		System.out.println(zebra);

		// banana.insertNode("")

		//
		// node.insertNode("banana");
		//
		// node.insertNode("peach");
		//
		// System.out.println(node);
		// System.out.println(node.left);
		//
		// System.out.println(node.right);
		//
		// node.zigRight();
		//
		// System.out.println(node);
		// System.out.println(node.left);
		//
		// System.out.println(node.right);

	}

}

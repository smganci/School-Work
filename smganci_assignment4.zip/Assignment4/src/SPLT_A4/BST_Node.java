package SPLT_A4;

/*
 * splay while nodes parent!=null
 * 
 * check remove
 * 
 * hook up to splay tree
 */

//not going to lie this is the uggliest code ever and i hate it but im too salty to delete my old code because what if i need it one day
public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;
	BST_Node par; // parent...not necessarily required, but can be useful in
					// splay tree
	boolean justMade; // could be helpful if you change some of the return types
						// on your BST_Node insert.
	// I personally use it to indicate to my SPLT insert whether or not we
	// increment size.

	BST_Node(String data) {
		this.data = data;
		this.justMade = true;

		left = null;
		right = null;
		par = null;
	}

	BST_Node(String data, BST_Node left, BST_Node right, BST_Node par) { // feel
																			// free
																			// to
																			// modify
																			// this
																			// constructor
																			// to
		// suit
		// your
		// needs
		this.data = data;
		this.left = left;
		this.right = right;
		this.par = par;
		this.justMade = true;
	}

	// --- used for testing ----------------------------------------------
	//
	// leave these 3 methods in, as is (meaning also make sure they do in fact
	// return data,left,right respectively)

	public String getData() {
		return data;
	}

	public BST_Node getLeft() {
		return left;
	}

	public BST_Node getRight() {
		return right;
	}

	public BST_Node getPar() {
		return par;
	}

	// --- end used for testing -------------------------------------------

	// --- Some example methods that could be helpful
	// ------------------------------------------
	//
	// add the meat of correct implementation logic to them if you wish

	// you MAY change the signatures if you wish...names too (we will not grade
	// on delegation for this assignment)
	// make them take more or different parameters
	// have them return different types
	//
	// you may use recursive or iterative implementations

	/*
	 * public BST_Node containsNode(String s){ return false; } //note: I
	 * personally find it easiest to make this return a Node,(that being the
	 * node splayed to root), you are however free to do what you wish. public
	 * BST_Node insertNode(String s){ return false; } //Really same logic as
	 * above note public boolean removeNode(String s){ return false; } //I
	 * personal do not use the removeNode internal method in my impl since it is
	 * rather easily done in SPLT, feel free to try to delegate this out,
	 * however we do not "remove" like we do in BST public BST_Node findMin(){
	 * return left; } public BST_Node findMax(){ return right; } public int
	 * getHeight(){ return 0; }
	 * 
	 * private void splay(BST_Node toSplay) { return false; } //you could have
	 * this return or take in whatever you want..so long as it will do the job
	 * internally. As a caller of SPLT functions, I should really have no idea
	 * if you are "splaying or not" //I of course, will be checking with tests
	 * and by eye to make sure you are indeed splaying //Pro tip: Making
	 * individual methods for rotateLeft and rotateRight might be a good idea!
	 */

	// --- end example methods --------------------------------------

	// --------------------------------------------------------------------
	// you may add any other methods you want to get the job done
	// --------------------------------------------------------------------

	public BST_Node containsNode(String s) { // it was me
		// if (data.equals(s))
		// return true;
		// if (data.compareTo(s) > 0) {// s lexiconically less than data
		// if (left == null)
		// return false;
		// return left.containsNode(s);
		// }
		// if (data.compareTo(s) < 0) {
		// if (right == null)
		// return false;
		// return right.containsNode(s);
		// }
		// return false; // shouldn't hit

		if (data.equals(s)) {
			return this;
		} else if (data.compareTo(s) > 0) {// s lexiconically less than data
			if (left == null) {
				return this;
			} else {

				return left.containsNode(s); // errors at this line
			}
		} else if (data.compareTo(s) < 0) {
			if (right == null) {
				return this;

			} else {
				return right.containsNode(s); // errors at this line?
			}

		}
		return this;// shouldn't hit
	}

	public BST_Node insertNode(String s) {
		if (data.compareTo(s) > 0) {
			if (left == null) {
				left = new BST_Node(s);
				left.par = this;
				return left;
			}
			return left.insertNode(s);
		}
		if (data.compareTo(s) < 0) {
			if (right == null) {
				right = new BST_Node(s);
				right.par = this;
				return right;
			}
			return right.insertNode(s);
		}
		return this;// ie we have a duplicate
	}

	public boolean removeNode(String s) { // DIO
		if (data == null) {
			return false;
		}
		if (data.equals(s)) {
			if (left != null) {
				data = left.findMax().data;
				left.removeNode(data);
				if (left.data == null)
					left = null;
			} else if (right != null) {
				data = right.findMin().data;
				right.removeNode(data);
				if (right.data == null)
					right = null;
			} else
				data = null;
			return true;
		} else if (data.compareTo(s) > 0) {
			if (left == null)
				return false;
			if (!left.removeNode(s))
				return false;
			if (left.data == null)
				left = null;
			return true;
		} else if (data.compareTo(s) < 0) {
			if (right == null)
				return false;
			if (!right.removeNode(s))
				return false;
			if (right.data == null)
				right = null;
			return true;
		}
		return false;
	}

	/*
	 * public boolean removeCompare(String s){ if(data==null){ return false; }
	 * 
	 * int compare = s.compareTo(data);
	 * 
	 * if (compare < 0) { if (left == null) { // return false if s is less than
	 * the current nodes data, but // left is null bc it cant exist return
	 * false;
	 * 
	 * } else { // recursively call remove on left node return
	 * left.removeNode(s); } } else if (compare > 0) { if (right == null) { //
	 * returns false when s is greater than value of data and would // happen in
	 * the right part of the tree, but there is no right // so it cant exist
	 * return false; } else { // recursive call to keep searching return
	 * right.removeNode( s); } } else { // this would happen if compare value is
	 * 0, and therefore a match
	 * 
	 * if (this.left != null && this.right != null) { // 2 children // Strategy:
	 * find new median leaf by getting the min value of data =
	 * right.findMin().data; right.removeNode(right.findMin().data);
	 * 
	 * } else if (parent.left == this) { // if the current node is the left
	 * child of the parent node that // we passed in, then we need to reassign
	 * the parents left to be // the current nodes left or right child depending
	 * on which of // the current nodes children is null
	 * 
	 * // old, slow, not fancy way: // if(left==null){ // parent.left=right; //
	 * }else{ // parent.left=left; // }
	 * 
	 * // book uses ternary(?) operator // parent.left = (left != null) ? left :
	 * right; } else if (parent.right == this) {
	 * 
	 * // old way // if(right==null){ // parent.right=left; // }else{ //
	 * parent.right=right; // }
	 * 
	 * parent.right = (left != null) ? left : right; }
	 * 
	 * return true;
	 * 
	 * } }
	 */
	public BST_Node findMin() {

		if (left == null) {
			return this;
		} else {
			// recursively call find min on the left node of the current node
			// will eventuall stop at base case when the next left is null
			return left.findMin();
		}
	}

	public BST_Node findMax() {
		if (right == null) {
			return this;
		} else {
			// recursively call find max on the right child of the current node
			// will eventually stop at base case
			return right.findMax(); // issues at this line
		}
	}

	public int getHeight() {
		int l = 0;
		int r = 0;
		if (left != null)
			l += left.getHeight() + 1;
		if (right != null)
			r += right.getHeight() + 1;
		return Integer.max(l, r);
	}

	public String toString() {
		return "Data: " + this.data + ", Left: " + ((this.left != null) ? left.data : "null") + ",Right: "
				+ ((this.right != null) ? right.data : "null") + ", Parent: "
				+ ((this.par != null) ? par.data : "null");
	}

	// zigLeft if if node is the right child of the parent
	// WORKING
	public void zigLeft() {

		// this code runs if the node passed in is the right child of the
		// current node

		// // the current nodes right nodes new parent is par
		// if (left != null) {
		// this.left.par = par;
		// }
		//
		// // the parents new left child is the current right node
		// par.right = this.left;
		//
		// // the new right is the parent
		// this.left = par;
		//
		// // the old parents new parent is this
		// left.par = this;
		//
		// par = null;

		BST_Node parent = this.par;
		BST_Node current = this;

		// currents parents right child (which is current) is assigned currents
		// left child
		current.par.right = current.left;

		if (current.left != null) {// if left is not null
			// the new parent of the left node is the currents parent
			current.left.par = current.par;
		}

		if (parent.par != null) {
			if (parent.isLeftChild()) {
				current.par.par.left = current;
				current.par = parent.par;
			} else {
				current.par.par.right = current;
				current.par = parent.par;
			}
		} else {
			current.par = null;
		}

		current.left = parent;
		current.left.par = current;

	}

	// zig right if the node is the left child of the parent

	// WORKING
	public void zigRight() {

		// the below version will work if you call the method on the parent node
		// with the child as the arguemnt
		// this code runs if the node passed in is the left child
		/*
		 * if (node.right != null) { node.right.par = this; }
		 * 
		 * this.left = node.right;
		 * 
		 * node.right = this;
		 * 
		 * node.par = null;
		 */

		// the below code will work if called on the node to be moved up

		// // if right is null dont want to access fields
		// if (right != null) {
		// // rights parent is parent of current
		// this.right.par = par;
		// }
		//
		// // pars new left is right
		// par.left = this.right;
		//
		// // the new left is par
		// this.right = par;
		//
		// // the new left which is parents par is this
		// right.par = this;

		BST_Node parent = this.par;
		BST_Node current = this;

		current.par.left = current.right;

		if (current.right != null) {
			current.right.par = current.par;
		}

		if (parent.par != null) {
			if (parent.isLeftChild()) {
				// if parent is the left child of the grandparent
				// the currents grandparents new left child is the current
				current.par.par.left = current;

				// the currents new parent is the parents parent
				current.par = parent.par;
			} else {// if parent is the rightChild
					// the currents grandparents new right child is the current
				current.par.par.right = current;

				// the new left child
				current.par = parent.par;
			}

		} else {
			// this would happen if there is none left to move up
			current.par = null;
		}

		// currents new right is parent
		current.right = parent;

		// the right things parent is current
		current.right.par = current;

	}

	// zigZig RR if the node is left child of parent and parent is left child of
	// grand parent
	// WORKING PRAISE GOD
	public void zigZigRR() {

		this.par.zigRight();
		this.zigRight();

		// BST_Node current = this;
		// BST_Node parent = par;
		// BST_Node grandParent = par.par;
		//
		// if (current.right != null) {
		// current.right.par = parent;
		// }
		// if (parent.right != null) {
		// parent.right.par = grandParent;
		// }
		// current.par = grandParent.par;
		// grandParent.par = par;
		// parent.par = current;
		//
		// // grandParent->left = parent->right;
		// grandParent.left = parent.right;
		// // parent->right = grandParent;
		// parent.right = grandParent;
		// // parent->left = current->right;
		// parent.left = current.right;
		// // current->right = parent;
		// current.right = parent;

	}

	// zigZig LL if the node is the right child of the parent and the parent is
	// the right child of the grand parent
	// WORKING
	public void zigZigLL() {
		this.par.zigLeft();
		this.zigLeft();

		// BST_Node current = this;
		// BST_Node parent = par;
		// BST_Node grandParent = par.par;
		//
		// // if (current->left)
		// // current->left->parent = parent;
		// if (current.left != null) {
		// current.left.par = parent;
		// }
		// // if (parent->left)
		// // parent->left->parent = grandParent;
		// if (parent.left != null) {
		// parent.getLeft().par = grandParent;
		// }
		// // current->parent = grandParent->parent;
		// current.par = grandParent.par;
		// // grandParent->parent = parent;
		// grandParent.par = parent;
		// // parent->parent = current;
		// parent.par = current;
		// // grandParent->right = parent->left;
		// grandParent.right = parent.left;
		// // parent->left = grandParent;
		// parent.left = grandParent;
		// // parent->right = current->left;
		// parent.right = current.left;
		// // current->left = parent;
		// current.left = parent;

	}

	// zigZagLR if node is right child of parent and parent is left of
	// grandparent
	// WORKING
	public void zigZagLR() {

		this.par.zigLeft();
		this.zigRight();
		// // parents new right is the current nodes left
		// par.right = this.left;
		//
		// if (this.left != null) {
		// // lefts new par is par
		// left.par = par;
		// }
		//
		// // new left is par
		// this.left = par;
		//
		// // new par is par.par
		//
		// this.par = par.par;
		//
		// // the new left childs parent is this
		// this.left.par = this;
		//
		// // now we can just call the method on the current values
		//
		// this.zigRight();

	}

	// zigZagRL if node is left of parent and parent is right of grandparent
	// WORKING
	public void zigZagRL() {
		this.par.zigRight();
		this.zigLeft();

		// // parents new left is the current nodes right
		// par.left = this.right;
		//
		// if (this.right != null) {
		// // rights new par is par
		// right.par = par;
		// }
		//
		// // new right is par
		// this.right = par;
		//
		// // new par is par.par
		//
		// this.par = par.par;
		//
		// // the new right childs parent is this
		// this.right.par = this;
		//
		// // now we can just rotate left
		// this.zigLeft();

	}

	public boolean splay() {

		/// BST_Node current = this;

		if (par == null) {
			return true;
		} else {
			if (this.isLeftChild()) {
				this.zigRight();
			} else if (this.isRightChild()) {
				this.zigLeft();
			}
			return this.splay();
		}

	}

	public boolean splay2() {

		/*
		 * if (par == null) {
		 * System.out.println("Made it to the root holllaaaaa"); return true; }
		 * else { if (this.isLeftChild()) { this.zigRight();
		 * System.out.println("Zig Right"); } else if (this.isRightChild()) {
		 * this.zigLeft(); System.out.println("ZigLeft"); } return this.splay();
		 * }
		 */

		if (par == null) {
			System.out.println("splay called on root");
			return true;

		} else if (this.par.getPar() == null) {
			if (this.isLeftChild()) {
				// if left child
				this.zigRight();
			} else if (this.isRightChild()) {
				// if right child
				this.zigLeft();

			}
		} else if (this.isRightChild() && par.isRightChild()) {
			// if right child of parent right child of grandparent
			this.zigZigLL();
		} else if (this.isLeftChild() && par.isLeftChild()) {
			// if left child of parent left child of grandparent
			this.zigZigRR();
		} else if (this.isLeftChild() && par.isRightChild()) {
			// if left child of parent right child of grandparent
			this.zigZagRL();

		} else if (this.isRightChild() && par.isLeftChild()) {
			// if left child of parent right child of grandparent
			this.zigZagLR();
		}

		// if (this.par != null) {
		// this.splay();
		//
		// }
		return this.splay2();

	}

	// public void splay(BST_Node node) {
	// node.splay();
	// }

	public boolean isRightChild() {
		if (par == null) {
			return false;
		}

		if (this.par.getRight() == this) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isLeftChild() {
		if (par == null) {
			return false;
		}

		if (this.par.getLeft() == this) {
			return true;
		} else {
			return false;
		}

	}

	public boolean nodeEqual(BST_Node node) {
		if (node == null) {
			return false;
		} else if (this.data.equals(node.data)) {
			return true;
		} else {
			return false;
		}
	}

}
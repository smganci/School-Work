package SPLT_A4;

public class SPLT implements SPLT_Interface {
	private BST_Node root;
	private int size;

	public SPLT() {
		this.size = 0;
		root = null;
	}

	public BST_Node getRoot() { // please keep this in here! I need your root
								// node to test your tree!
		return root;
	}

	@Override
	public void insert(String s) {
		if (root == null) {
			size++;
			root = new BST_Node(s);

		} else {
			if (root.containsNode(s).data.equals(s)) {
				BST_Node newRoot = root.containsNode(s);
				// while (newRoot.par != null) {
				// newRoot.splay();
				// }
				newRoot.splay();
				root = newRoot;
			} else {
				BST_Node insert = root.insertNode(s);
				// while (insert.par != null) {
				// insert.splay();
				// }
				insert.splay();

				root = insert;
				size++;
			}
		}

	}

	@Override
	public void remove(String s) {
		// this will make the root be the s if its there
		// if (empty()) {
		// return;
		// }

		boolean contains;

		if (root != null) {
			contains = this.contains(s);
		} else {
			contains = false;
		}

		if (contains) {
			if (size == 1) {
				root = null;
				size--;
			} else {

				BST_Node leftTree = root.left;

				BST_Node rightTree = root.right;

				// unhook root
				root = null;

				if (leftTree != null) {
					leftTree.par = null;
					// splay the max of the left tree
					BST_Node max = leftTree.findMax();
					// while (max.par != null) {
					// max.splay();
					// }
					max.splay();

					leftTree = max;
					leftTree.par = null;

					// somehow by magic the left tree just doesnt have a right
					// child
					// so make the left trees right child the rightTree
					leftTree.right = rightTree;
					if (rightTree != null) {
						rightTree.par = leftTree;
					}

					// root is the leftTree
					root = leftTree;
				} else {
					rightTree.par = null;
					root = rightTree;
				}

				size--;

			}
		}
	}

	@Override
	public String findMin() {

		if (empty() && root == null) {
			return null;

		} else {
			BST_Node min = root.findMin();
			// while (min.par != null) {
			// min.splay();
			// }

			min.splay();

			root = min;

			return min.data;
		}

	}

	@Override
	public String findMax() {
		// TODO Auto-generated method stub

		if (empty() && root == null) {
			return null;
		} else {
			BST_Node max = root.findMax();
			// while (max.par != null) {
			// max.splay();
			// }
			max.splay();

			root = max;
			return max.data;
		}
	}

	@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return size == 0;
	}

	@Override
	public boolean contains(String s) {
		// TODO Auto-generated method stub

		if (empty()) {
			return false;
		}

		BST_Node got = root.containsNode(s);

		if (got != null) {
			// while (got.par != null) {
			// got.splay();
			// }
			got.splay();

			root = got;

			if (got.data.compareTo(s) == 0) {
				return true;
			} else {
				return false;
			}
		}

		return false;

	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int height() {
		if (empty()) {
			return -1;
		} else if (size == 1) {
			return 0;
		} else {

			return root.getHeight();
		}
	}

}